import dev.robocode.tankroyale.botapi.Bot;
import dev.robocode.tankroyale.botapi.BotInfo;
import dev.robocode.tankroyale.botapi.events.*;

//Recuerda reemplazar (refactorizar) el nombre de IABDBot por tu nombre,
//y recuerda que debes hacerlo también en el resto de ficheros de la carpeta.
public class IABDBot extends Bot {
    //Declaración de variables globales o constantes, se mantienen durante el combate.
    double moveDirection = 1;
    private double ultimoEnemigoVisto;
    private int wallMargin = 60;
    private int tooCloseToWall = 0;

    // Constructor, que carga el fichero de configuración
    IABDBot() {
        super(BotInfo.fromFile("src/IABDBot.json"));
    }

    // Este método inicializa nuestro Bot
    public static void main(String[] args) {
        new IABDBot().start();
    }

    public static double miMetodo(double angle) {
        //Métodos propios que podemos añadir.
        return 0;
    }

    // Don't get too close to the walls


    @Override
    public void run() {
        //Se ejecuta en cada turno
        setAdjustRadarForBodyTurn(true);//true if the radar must adjust/compensate for the body's turn;
        //false if the radar must turn with the body turning (default).
        setAdjustGunForBodyTurn(true);  //true if the gun must adjust/compensate for the bot's turn;
        //false if the gun must turn with the bot's turn.
        setAdjustRadarForGunTurn(true); //true if the radar must adjust/compensate for the gun's turn;
        //false if the radar must turn with the gun's turn.
        setTurnRadarLeft(Double.POSITIVE_INFINITY); //degrees - is the amount of degrees to turn left. If negative, the radar will turn right.
        rescan();
        // No te acerques mucho a las paredes
        addCustomEvent(new Condition("TooCloseToWalls") {
            public boolean test() {
                // El método test() es el que debemos reescribir para definir el resultado de nuestra condición.
                return (
                        // we're too close to the left wall
                        ((getX() <= wallMargin) ||
                                // or we're too close to the right wall
                                (getX() >= getArenaWidth() - wallMargin) ||
                                // or we're too close to the bottom wall
                                (getY() <= wallMargin) ||
                                // or we're too close to the top wall
                                (getY() >= getArenaHeight() - wallMargin))
                );
            }
        });
        while (isRunning()) {
            doMove();
            go();
            //Compara el funcionamiento de los dos bloques, comentando uno cada vez
            //BLOQUE 1: Movimientos bloqueantes, hasta que no acaba uno, no empieza el siguiente
//            forward(100);
//            turnGunRight(360);
//            back(100);
//            turnGunRight(360);

//            //BLOQUE 2: Movimientos no bloqueantes, usando waitFor y condiciones (o go()).
//            // Le decimos al robot que queremos avanzar 1000 unidades
//            setForward(1000);
//            // Le decimos también que queremos dar una vuelta completa al cañon
//            setTurnGunRight(360);
//            // En este punto le hemos dicho al robot que "queremos hacer algo"
//            // queremos avanzar y girar el cañon. Eso es lo que significan los "set".
//            // Es importante darse cuenta de que todavía no hemos hecho nada!
//            // para comenzar a movernos, debemos llamar al método waitFor.
//            // waitFor comienza la acción -- empezamos a movernos mientras giramos el cañon (todo a la vez).
//            // Podemos crear nuestras propias condiciones, o llamar directamente a funciones lambda como en el siguiente ejemplo:
//            waitFor(new Condition(() -> getGunTurnRemaining() == 0 || getDistanceRemaining() == 0));
//            // El waitFor anterior espera a que se termine de avanzar o se termine de dar la vuelta al cañon, lo que pase antes.
//            // Una vez alcanzada la condición, pedimos al Bot que vuelva para atrás y dé otra vuelta de cañon
//            setBack(1000);
//            setTurnGunRight(360);
//            // ... y volvemos a esperar ...
//            waitFor(new Condition(() -> getGunTurnRemaining() == 0 || getDistanceRemaining() == 0));
//            // Ahora volveremos al inicio del bucle.
//
//            //¿Qué es mejor? Pues depende...
        }
    }

    @Override
//    public void onScannedBot(ScannedBotEvent e) {
//        double factor=1;
//        setTurnRadarLeft(factor * radarBearingTo(e.getX(), e.getY()));
//        turnLeft(e.getDirection() + 90);
//    }

    public void onScannedBot(ScannedBotEvent e) {
        // Absolute angle towards target
        double angleToEnemy = radarBearingTo(e.getX(), e.getY());
        ultimoEnemigoVisto = bearingTo(e.getX(), e.getY());

        // Distance we want to scan from middle of enemy to either side
        // The 36.0 is how many units from the center of the enemy robot it scans.
        double extraTurn = Math.min(Math.toDegrees(Math.atan(36.0 / distanceTo(e.getX(), e.getY()))), getMaxRadarTurnRate());
        //double extraTurn = Math.min((Math.atan(36.0 / distanceTo(e.getX(), e.getY()))), getMaxRadarTurnRate());

        // Adjust the radar turn so it goes that much further in the direction it is going to turn
        // Basically if we were going to turn it left, turn it even more left, if right, turn more right.
        // This allows us to overshoot our enemy so that we get a good sweep that will not slip.
        if (angleToEnemy < 0)
            angleToEnemy -= extraTurn;
        else
            angleToEnemy += extraTurn;

        //Turn the radar
        setTurnRadarLeft(angleToEnemy);

        // calcular la potencia basado en la distancia
        double enemyDistance = distanceTo(e.getX(), e.getY());
        double firePower = Math.min(500 / enemyDistance, 3);
        //if (!apuntando) {
        // calcular la velocidad de la bala
        double bulletSpeed = 20 - firePower * 3;
        // calculamos el tiempo que necesita la bala para impactar al enemigo
        long time = (long) (enemyDistance / bulletSpeed);

        // Calcular la velocidad actual de tu enemigo
        double enemyVelocity = e.getSpeed();

        // Calcular la dirección actual del enemigo
        double enemyDirection = e.getDirection();

        // Calcular el desplazamiento en las coordenadas X e Y
        // Componente X del desplazamiento COSENO
        double deltaX = enemyVelocity * (Math.cos(Math.toRadians(enemyDirection)));
        // Componente Y del desplazamiento SENO
        double deltaY = enemyVelocity * (Math.sin(Math.toRadians(enemyDirection)));

        // Calcular las coordenadas futuras
        //TODO: Revisar cuando sobrepase el tamaño del terreno de juego.
        double futureX = e.getX() + (deltaX * (time));
        double futureY = e.getY() + (deltaY * (time));

        // turn the gun to the predicted x,y location
        setTurnGunLeft(gunBearingTo(futureX, futureY));
        if (getGunTurnRemaining() <= 0.1 && getGunHeat() == 0) {
            System.out.println("FIREEEEE!!!: " + firePower);
            fire(firePower);
            //    apuntando = false;
        }
    }

    // We were hit by a bullet -> turn perpendicular to the bullet
    @Override
    public void onHitByBullet(HitByBulletEvent e) {
        // Calculate the bearing to the direction of the bullet
        //double bearing = calcBearing(e.getBullet().getDirection());

        // Turn 90 degrees to the bullet direction based on the bearing
        //setTurnLeft(90 - bearing);
    }

    public void doMove() {
        setTurnLeft(ultimoEnemigoVisto + (90-(20*moveDirection)));
        //setTurnLeft(ultimoEnemigoVisto + (90-(20*moveDirection)));
        // switch directions if we've stopped
//        if (getSpeed() == 0) {
//            moveDirection *= -1;
//
//        }
        // circle our enemy
        //if ((getTurnNumber() % 40 == 0)) {
//            System.out.println("CAMBIO");
        //    moveDirection *= -1;
        //    setForward(1000 * moveDirection);
        //}
        //setForward(1000 * moveDirection);
        // if we're close to the wall, eventually, we'll move away
        if (tooCloseToWall > 0) tooCloseToWall--;

        // switch directions if we've stopped
        if (getSpeed() == 0) {
            setMaxSpeed(8);
            moveDirection *= -1;
            setForward(1000 * moveDirection);
        }
    }

    @Override
    public void onBotDeath(BotDeathEvent botDeathEvent) {
        setTurnRadarLeft(Double.POSITIVE_INFINITY);
        System.out.println("Robot muerto, rescan()!");
    }

    public void onCustomEvent(CustomEvent e) {
        if (e.getCondition().getName().equals("TooCloseToWalls")) {
            System.out.println("WALL!");
            if (tooCloseToWall <= 0) {
                // Si no estábamos ya cerca de las paredes, ahora lo estamos
                tooCloseToWall += wallMargin;
                setMaxSpeed(0); // Para!!!
            }
        }
    }
}